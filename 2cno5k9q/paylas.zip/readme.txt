open the installer.bat first and the .bat file gonna build it and open the music ıf you opened .bat file you dont have to open again you have to open the .exe file
if you pressed Google ile giriş yap button and no pop-up comed you have to click again
and if you open the .exe file a one folder created and .exe file will open that and you should not delete that folder. 

                      

                                             $$$$$$\                            $$\                           $$\      $$\                     $$\           
                                            $$  __$$\                           $$ |                          $$$\    $$$ |                    \__|          
                                            $$ /  \__| $$$$$$\   $$$$$$\   $$$$$$$ | $$$$$$\   $$$$$$$\       $$$$\  $$$$ |$$\   $$\  $$$$$$$\ $$\  $$$$$$$\ 
                                            $$ |      $$  __$$\ $$  __$$\ $$  __$$ |$$  __$$\ $$  _____|      $$\$$\$$ $$ |$$ |  $$ |$$  _____|$$ |$$  _____|
                                            $$ |      $$ |  \__|$$$$$$$$ |$$ /  $$ |$$ /  $$ |\$$$$$$\        $$ \$$$  $$ |$$ |  $$ |\$$$$$$\  $$ |$$ /      
                                            $$ |  $$\ $$ |      $$   ____|$$ |  $$ |$$ |  $$ | \____$$\       $$ |\$  /$$ |$$ |  $$ | \____$$\ $$ |$$ |      
                                            \$$$$$$  |$$ |      \$$$$$$$\ \$$$$$$$ |\$$$$$$  |$$$$$$$  |      $$ | \_/ $$ |\$$$$$$  |$$$$$$$  |$$ |\$$$$$$$\ 
                                             \______/ \__|       \_______| \_______| \______/ \_______/       \__|     \__| \______/ \_______/ \__| \_______|
                                                                                                                 
                                                                                  